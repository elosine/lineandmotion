import {
  Geometry
} from '../../../src/Three';

export class ExplodeModifier {
  constructor();
  modify(geometry: Geometry): void;
}
