import {
  Mesh
} from '../../../src/Three';

export class Sky extends Mesh {
  constructor();

  static SkyShader: object;
}
