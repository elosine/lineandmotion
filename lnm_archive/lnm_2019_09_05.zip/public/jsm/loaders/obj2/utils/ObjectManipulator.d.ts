export namespace ObjectManipulator {
  export function applyProperties(objToAlter: object, params: object, forceCreation: boolean): void;
}
