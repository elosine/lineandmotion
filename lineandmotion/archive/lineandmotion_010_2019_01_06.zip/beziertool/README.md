# HTML5 <canvas> bezierCurveTo command generator

A tool that allows you to generate [bezierCurveTo](https://developer.mozilla.org/en-US/docs/Web/API/CanvasRenderingContext2D/bezierCurveTo) commands via a simple web GUI:
* [http://www.victoriakirst.com/beziertool/](http://www.victoriakirst.com/beziertool/)

Written one afternoon in 2011 (!) when I was just a baby programmer. Turns out in even in 2017, I still get a fair number of questions about it (!!) so I went ahead and put it on GitHub.

## Status
**NOT** under active development. The code hasn't been touched since 2011! Feel free to fork, or contact me if you really want to send a pull request.
